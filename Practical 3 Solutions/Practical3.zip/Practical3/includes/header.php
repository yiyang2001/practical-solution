<header>
    <h1>Practical 2 Combined</h1>
</header>

<nav>
    <a href="kinder-math-ques.php">[Kinder Math Questions</a> |
    <a href="register-student.php">Register Student</a> |
    <a href="clubs-join.php">Join Clubs</a> |
    <a href="simple-calculator.php">Simple Calculator]</a>
</nav>