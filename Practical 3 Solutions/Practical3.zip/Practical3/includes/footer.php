<footer style="border-top: 1px dashed #999; margin-top: 20px;">
    <p>&copy;Copyright 2024 by <b>Teo Yi Yang</b>. All rights Reserved.</p>
</footer>