<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <title>Practical 2</title>
        <link type="text/css" href="css/style.css" rel="stylesheet" />
    </head>
    <body>
        <h1>Practical 3</h1>
        <ul>
            <li>Q1: <a href="kinder-math-ques.php">kinder-math-ques.php</a></li>
            <li>Q2: <a href="clubs-join.php">clubs-join.php</a></li>
            <li>Q3: <a href="simple-calculator.php">simple-calculator.php</a></li>
            <li>Q4: <a href="register-student.php">register-student.php</a></li>
            <li>Q5: Refer to project folder named [practical-2-5]</li>
            <li><a href="/index.php">[Back]</a></li>
        </ul>
    </body>
</html>
