<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>P1Q6</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
    <?php
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $now = date('d-F-Y h:i:s A'); // Chapter 2-2 PHP Decision and Loops - slide 10 
    echo "<h1>$now</h1>";
    ?>

    <p>
        [ <a href="index.php">Back</a> ]
    </p>
</body>

</html>