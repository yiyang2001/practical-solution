<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Practical 2</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
    <h1>Practical 2</h1>
    <ul>
        <li><a href="P2Q1.php">P1Q1</a></li>
        <li><a href="P2Q2.php">P1Q2</a></li>
        <li><a href="P2Q3.php">P1Q3</a></li>
        <li><a href="P2Q4.php">P1Q4</a></li>
        <li><a href="P2Q5.php">P1Q5</a></li>
        <li><a href="P2Q6.php">P1Q6</a></li>
        <li><a href="P2Q7.php">P1Q7</a></li>
        <li><a href="P2Q8.php">P1Q8</a></li>
        <li><a href="P2Q9.php">P1Q9</a></li>
        <li><a href="P2Q10.php">P1Q10</a></li>
        <li><a href="/index.php">[Back]</a></li>
    </ul>
</body>

</html>