<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            // this function will return student's grade based on their mark.
            function getGrade($mark){
                // range = 80 - 100
                if ($mark >= 80 && $mark <= 100){
                    return "A";
                }
                // range = 70 - 79
                else if ($mark >= 70 && $mark < 80){
                    return "B";
                }
                // range = 60 - 69
                else if ($mark >= 60 && $mark < 70){
                    return "B";
                }
                // range = 50 - 59
                else if ($mark >= 50 && $mark < 60){
                    return "B";
                }
                // range = 0 - 49
                else if ($mark >=0 && $mark < 50){
                    return "F";
                }
            }
            
            // this function will return student's comment based on their grade.
            function getComment($grade){
                switch ($grade){
                    case 'A':
                        return "Passed with distinction";
                        break;
                    // if grade is B or C
                    case 'B':
                    case 'C':
                        return "Passed";
                        break;
                    case 'D':
                        return "Passed with condition";
                        break;
                    case 'F':
                        return "Failed";
                        break;
                    default : break;
                }
            }
            
            $students = array(
                "Alex" => 90,
                "Barbie" => 65,
                "Christine" => 45,
                "Danny" => 55,
                "Elain" => 75
            );
        ?>
        
        <table>
            <tr>
                <th>Name</th>
                <th>Mark</th>
                <th>Grade</th>
                <th>Comment</th>
            </tr>
            <?php 
                    foreach ($students as $name => $mark) {
                        echo "<tr>";
                        echo "<td>" . $name ."</td>";
                        echo "<td>" . $mark ."</td>";
                        
                        // create a new variable to store student's grade
                        $grade = getGrade($mark);
                        echo "<td>" . $grade ."</td>";
                        // create a new variable to store student's comment
                        $comment = getComment($grade);
                        echo "<td>" . $comment ."</td>";
                        echo "</tr>";
                    }
            ?>
        </table>
    </body>
</html>
