<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>
            <?php
                // Set the correct timezone to M'sia
                date_default_timezone_set("Asia/Kuala_Lumpur");
            
                // Print the date
                // l = day (Sunday - Saturday)
                // d = 2 digit day
                // F = full month name (January - December)
                // Y = 4 digit year (e.g. 2021, 2020....)
                // h = 2 digit hour
                // i = 2 digit minute
                // s = 2 digit second
                // A = uppercase AM / PM
                // a = lowercase am / pm
                echo(date("d-F-Y h:i:s A"));
            ?>
        </h1>
        
    </body>
</html>

