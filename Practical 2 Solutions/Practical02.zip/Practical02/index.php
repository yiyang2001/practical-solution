<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Practical 02</h1>
        <hr/>
        
        <!-- target="_blank" means open in new tab -->
        <a href="./q1.php" target="_blank">Question 1</a>
        <br/>
        <a href="./q2.php" target="_blank">Question 2</a>
        <br/>
        <a href="./q3.php" target="_blank">Question 3</a>
        <br/>
        <a href="./q4.php" target="_blank">Question 4</a>
        <br/>
        <a href="./q5.php" target="_blank">Question 5</a>
        <?php
        // put your code here
        ?>
    </body>
</html>
