<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            // Initialize default variables
            $s1 = 'INVALID-ID';
            $s2 = '1234567890';
            $s3 = '00XXX12345';
            $s4 = '00WAD12345';
            
            // "\d{2}" = accept 2 digits
            // "[A-Z]{3}" = accept 3 uppercase alphabets
            // "\d{5}" = accept 5 digits
            // ^ = to indicate start of string
            // $ = to indicate end of string
            // "/..../" = you are checking the pattern of a string
            // "[ACJPSW]{1}" = accept any ONE only from A,C,J,P,S,W
            // "[ABHPT]{1}" = accept any ONE only from A,B,H,P,T
            // "[ABCDP]{1}" = accept any ONE only from A,B,C,D,P
            $pattern = "/^\d{2}[ACJPSW]{1}[ABHPT]{1}[ABCDP]{1}\d{5}$/";
            
            $str = "hello world";
            
            echo "<pre>" . $s1 . " = " . (preg_match($pattern, $s1)? "Match" : "Not Match") ."</pre>";
            echo "<pre>" . $s2 . " = " . (preg_match($pattern, $s2)? "Match" : "Not Match") ."</pre>";
            echo "<pre>" . $s3 . " = " . (preg_match($pattern, $s3)? "Match" : "Not Match") ."</pre>";
            echo "<pre>" . $s4 . " = " . (preg_match($pattern, $s4)? "Match" : "Not Match") ."</pre>";
            ?>
    </body>
</html>
