<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $data = array(
               "AACS3013" => 70,
               "AACS3073" => 95,
               "AAMS3683" => 55,
               "AACS3034" => 75,
               "AHLA3413" => 65
            );
            
        ?>
        <table>
            <tr>
                <th style="background-color: #cccccc;">COURSE</th>
                <th style="background-color: #cccccc; width: 350px">PASSING RATE</th>
            </tr>
            
            <?php 
                foreach ($data as $course => $passingRate) {
                    echo "<tr>";
                    echo "<td>" . $course . "</td>";
                    echo "<td>" . "<span "
                            . "style='display: inline-block; "
                            // set background colour based on condition
                            . "background-color:" . ($passingRate >= 70 ? "lightblue" : "pink") . ";"
                            // set width based on condition
                            . "width: " . ($passingRate / 100) * 250 ."px;'>&nbsp;</span>" .
                            $passingRate ." %</td>";
                    echo "</tr>";
                }   
            ?>
    </body>
</html>