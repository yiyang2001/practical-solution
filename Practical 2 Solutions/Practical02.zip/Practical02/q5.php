<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table border="1">
            <?php
                // Loop row for 10 times
                for ($row = 1; $row <= 10; $row++){
                    echo ("<tr>");
                    for ($col = 1; $col <= 15; $col ++){
                        
                        // Method 1
                         if (($row + $col) % 2 == 0){
                             echo ("<td style='width: 10px; height: 15px; background-color: pink;'></td>");
                         }
                         else{
                            echo ("<td style='width: 10px; height: 15px; background-color: white;'></td>");
                         }
                        
                        
                        // Method 2
                        // to check if both row and col is even number 
                        //if (($row % 2 == 0) && ($col % 2 == 0)){
                        //    echo ("<td style='width: 10px; height: 15px; background-color: pink;'></td>");
                        //}
                        // to check if both row and col is odd number
                        //else if (($row % 2 == 1) && ($col % 2 == 1)){
                        //    echo ("<td style='width: 10px; height: 15px; background-color: pink;'></td>");
                        //}
                        //else{
                        //    echo ("<td style='width: 10px; height: 15px; background-color: white;'></td>");
                        //}
                    }
                    echo ("</tr>");
                }
            ?>
        </table>
        
    </body>
</html>